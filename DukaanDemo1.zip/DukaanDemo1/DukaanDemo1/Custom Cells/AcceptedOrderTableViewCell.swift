//
//  AcceptedOrderTableViewCell.swift
//  DukaanDemo1
//
//  Created by Arora, Prateek on 26/03/21.
//

import UIKit

class AcceptedOrderTableViewCell: UITableViewCell {
    @IBOutlet weak var cancelOrderButton: UIButton!
    
    @IBOutlet weak var orderStatusLabel: UILabel!
    @IBOutlet weak var timeStampLabel: UILabel!
    @IBOutlet weak var itemLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var thumbNailImageView: UIImageView!
    @IBOutlet weak var orderLabel   : UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
       orderStatusLabel.backgroundColor = UIColor.red.withAlphaComponent(0.15)

        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
