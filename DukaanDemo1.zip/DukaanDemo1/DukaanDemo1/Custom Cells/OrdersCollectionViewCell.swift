//
//  OrdersCollectionViewCell.swift
//  DukaanDemo1
//
//  Created by Arora, Prateek on 26/03/21.
//

import UIKit

class OrdersCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var orderButton: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
