//
//  HomeViewController.swift
//  DukaanDemo1
//
//  Created by Arora, Prateek on 25/03/21.
//

import UIKit

class HomeViewController: UIViewController,UICollectionViewDelegate, UICollectionViewDataSource,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var whatsAppButton: UIButton!
    @IBOutlet weak var dukaanHyperlinkBurron: UIButton!
    @IBOutlet weak var acceptedOrderTableView: UITableView!
    @IBOutlet weak var orderButtonCollectionView: UICollectionView!
    
    var items = ["Pending (129)","Accepted (13)", "Shipped (201)"]
    let reuseIdentifier = "cell"
    let tableReuseIdentifier = "tableCell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        scrollView.contentSize = CGSize(width: 400, height: 1200)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        self.orderButtonCollectionView.delegate = self
        
        self.orderButtonCollectionView.dataSource = self
        self.acceptedOrderTableView.delegate = self
        self.acceptedOrderTableView.dataSource = self
        orderButtonCollectionView.register(UINib(nibName:"OrdersCollectionViewCell", bundle: nil), forCellWithReuseIdentifier:reuseIdentifier)
        acceptedOrderTableView.register(UINib(nibName: "AcceptedOrderTableViewCell", bundle: nil), forCellReuseIdentifier: tableReuseIdentifier)
    }
    override func viewDidAppear(_ animated: Bool) {
        if #available(iOS 13, *)
        {
            let keyWindow = UIApplication.shared.connectedScenes
                    .filter({$0.activationState == .foregroundActive})
                    .map({$0 as? UIWindowScene})
                    .compactMap({$0})
                    .first?.windows
                    .filter({$0.isKeyWindow}).first
            
            let statusBar = UIView(frame: (keyWindow?.windowScene?.statusBarManager?.statusBarFrame)!)
            statusBar.backgroundColor = UIColor(red: 51/255.0, green: 110/255.0, blue: 175/255.0, alpha: 0)
            keyWindow?.addSubview(statusBar)
        }
    }

}


// MARK: Table view Delegates and Data source
extension HomeViewController {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: tableReuseIdentifier, for: indexPath as IndexPath) as! AcceptedOrderTableViewCell
        cell.orderStatusLabel.backgroundColor?.withAlphaComponent(0.15)
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 160
    }
}

// MARK: Collection view Delegates and Data source
extension HomeViewController {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.items.count
        
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath as IndexPath) as! OrdersCollectionViewCell
        
        cell.layer.borderColor = UIColor.lightGray.cgColor
        cell.layer.cornerRadius = 16
        cell.orderButton.setTitle(items[indexPath.row], for: .normal)
        cell.orderButton.setTitleColor(UIColor(red: 128/255.0, green: 128/255.0, blue: 128/255.0, alpha: 1.0), for: .normal)
        cell.orderButton.backgroundColor = UIColor(red: 230.0/255.0, green: 230.0/255.0, blue: 230.0/255.0, alpha: 1.0)

        if indexPath.row == 1 {
            cell.orderButton.tag = 101
            cell.orderButton.backgroundColor = UIColor(red: 20/255.0, green: 110/255.0, blue: 180/255.0, alpha: 1.0)
            cell.orderButton.setTitleColor(UIColor.white, for: .normal)
        }
        return cell
    }
    
}
